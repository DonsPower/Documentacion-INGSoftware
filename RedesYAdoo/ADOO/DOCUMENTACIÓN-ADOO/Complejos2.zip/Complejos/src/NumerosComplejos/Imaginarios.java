/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NumerosComplejos;

/**
 *
 * @author César Iván Martínez
 */
public  class Imaginarios {
    
    protected float real;
    protected float imaginaria;
 
    

    public Imaginarios(float real, float imaginaria) {
        this.real = real;
        this.imaginaria = imaginaria;
      
    }

    public Imaginarios() {
        
        this.imaginaria=0;
        this.real=0;
        
    }
    
    
    
    ///Calcular el modulo
    public float  CalModulo()
      {
       return  (float ) Math.sqrt(Math.pow(this.real,2)+ Math.pow((this.imaginaria),2));
      } 
    
    
    ////Suma 
    
    public Imaginarios suma(Imaginarios n1){
        
        Imaginarios total = new Imaginarios();
        
        total.real=(this.real+n1.real);
        total.imaginaria=(this.imaginaria+n1.imaginaria);
        
        return total;
    }
    
    
    //Resta
    
     public Imaginarios resta(Imaginarios n1){
        
        Imaginarios total = new Imaginarios();
        
        total.real=(this.real-n1.real);
        total.imaginaria=(this.imaginaria-n1.imaginaria);
        
        return total;
    }
     
     //Multiplicacion

    
     public Imaginarios multiplicacion(Imaginarios n1){
         
                 Imaginarios total = new Imaginarios();
                 
                 total.real=( (this.real*n1.real) - (this.imaginaria*n1.imaginaria) );
                 total.imaginaria=( (this.real*n1.imaginaria) + (this.imaginaria*n1.real) );

         
         return total;
     }
     
     //División
     
public Imaginarios division(Imaginarios n1){
         
         Imaginarios total = new Imaginarios();
                 
                 total.real=( ((this.real*n1.real)+(this.imaginaria*n1.imaginaria))/( (n1.real*n1.real)+ (n1.imaginaria*n1.imaginaria ) ) );
                 total.imaginaria=( ((this.real*n1.imaginaria)-(this.imaginaria*n1.real))/( (n1.real*n1.real)+ (n1.imaginaria*n1.imaginaria ) ) );

         
         return total;
 }
     
     
    
    
////Set and Get de los atributos principales
    public float getReal() {
        return real;
    }

    public void setReal(float real) {
        this.real = real;
    }

    public float getImaginaria() {
        return imaginaria;
    }
    
   public void setImaginaria(float imaginaria) {
        this.imaginaria = imaginaria;
    }
    
   /// Get especial para retornar Modulo
   public float getModulo(){
       
       return CalModulo();
       
   }
    

    
    
    
}

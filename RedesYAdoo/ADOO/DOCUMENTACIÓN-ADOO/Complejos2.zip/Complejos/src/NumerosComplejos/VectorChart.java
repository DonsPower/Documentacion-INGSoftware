/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NumerosComplejos;

import java.awt.Color;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.VectorRenderer;
import org.jfree.data.xy.VectorSeries;
import org.jfree.data.xy.VectorSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleInsets;

/**
 *
 * @author César Iván Martínez
 */
public class VectorChart extends ApplicationFrame {
    JFreeChart theChart;


    private String chartTitle, xAxisTitle, yAxisTitle;

    VectorSeriesCollection dataSet = new VectorSeriesCollection();

    public VectorChart(String title, String xAxisTitle, String yAxisTitle)
    {
        super(title);
        this.chartTitle = title;
        this.xAxisTitle = xAxisTitle;
        this.yAxisTitle = yAxisTitle;
    }

    public void addSeries(String seriesTitle)
    {
        VectorSeries vectorSeries = new VectorSeries(seriesTitle);
        dataSet.addSeries(vectorSeries);
    }
    
    
    public void addValuesToSeries(int seriesNo, double  x, double y, double deltaX, double deltaY)
    {
        dataSet.getSeries(seriesNo).add(x, y, deltaX, deltaY);
    }

    public void addValuesToSeries(String seriesTitle, double x, double y, double deltaX, double deltaY)
    {
        int index = dataSet.indexOf(seriesTitle);
        addValuesToSeries(index, x, y, deltaX, deltaY);

    }

    public ChartPanel createChart()
    {
        XYPlot xyPlot = new XYPlot();


        xyPlot.setOrientation(PlotOrientation.VERTICAL);
        xyPlot.setDataset(this.dataSet);

        xyPlot.setBackgroundPaint(Color.white);
        xyPlot.setDomainGridlinePaint(Color.darkGray);
        xyPlot.setRangeGridlinePaint(Color.darkGray);
        xyPlot.setAxisOffset(new RectangleInsets(5.0, 5.0, 5.0, 5.0));


        VectorRenderer r = new VectorRenderer();
        r.setBasePaint(Color.white);
        r.setSeriesPaint(0, Color.blue);

        xyPlot.setRenderer(r);
        theChart = new JFreeChart(xyPlot);
        theChart.setTitle(chartTitle);

        ChartPanel panel = new ChartPanel(theChart);
        panel.setFillZoomRectangle(true);
        panel.setMouseWheelEnabled(true);
        panel.setPreferredSize(new java.awt.Dimension(500,500));
        setContentPane(panel);
        return panel;
    }

     public static void main(String[] args){
         
         // create a dataset...
// First we create a dataset   
 
// We create a vector series collection   
VectorSeriesCollection dataSet= new VectorSeriesCollection();
   
VectorSeries vectorSeries=new VectorSeries("Numeros Complejos");

vectorSeries.add(0, 0, 5, 5);
vectorSeries.add(1, 4, 3, -2);
vectorSeries.add(4, 5, 2, 1);
vectorSeries.add(10, 0, 0, -5);
vectorSeries.add(0, 9, 9, 0);
vectorSeries.add(2, 1, -4, 5);
vectorSeries.add(4, 4, 5, 9);
vectorSeries.add(1, 10, -4, 2);

dataSet.addSeries(vectorSeries);   



VectorRenderer r = new VectorRenderer();
//r.setBasePaint(Color.white);
//r.setSeriesPaint(0, Color.blue);

XYPlot xyPlot = new XYPlot(dataSet, new NumberAxis("Parte Real"), new NumberAxis("Parte Imaginaria"), r);

// Create a Chart
JFreeChart theChart;

theChart = new JFreeChart(xyPlot);
theChart.setTitle("Plano Complejo");

// create and display a frame...
ChartFrame frame = new ChartFrame("First", theChart);
frame.pack();
frame.setVisible(true);

}
     

}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NumerosComplejos;

import static java.lang.Math.atan;
import java.util.ArrayList;

/**
 *
 * @author César Iván Martínez
 */
public class Conversiones {
    
   ///Aqui esta el arreglo global en donde se guardan los numeros en su forma compleja, para llenarlo previamente se debe  
    //Hacer funvionar el metodo ******public String Raices(Imaginarios im, int n)****** 
    
   
   ArrayList<Imaginarios> arreglo = new ArrayList<Imaginarios>();
   
    public float angulo;
    public float mod;
  
    
   
   public Conversiones(){
        
  }
    
  
    public void angulo(Imaginarios im){
        
        float coseno, seno;
        mod=im.CalModulo();
        
        if(im.real==-1&&im.imaginaria==0)
        {
            this.angulo=180;
        }
        else{
                   coseno=im.real/mod;
	seno=im.imaginaria/mod;
        
	angulo=(float) ((atan(seno/coseno))*57.295779513);
        }
        
        if(angulo<0){
            
            angulo=360+angulo;
        }
 
        
 }
    
    public float getAngulo() {
       return angulo;
    }

 
    public float getMod() {
        return mod;
    }


    public String trigonometrica(Imaginarios im){
        
        this.angulo(im);
        
        return this.mod+"(Cos("+this.angulo+"°) + iSen("+this.angulo+"°)";
        
    }
    
    
    
     public String euler(Imaginarios im){
        
        this.angulo(im);
        
        
        return this.mod+"e^( "+this.angulo+"°)i";
        
        
    }
     
     
     
      public String Raices(Imaginarios im, int n){
          
       String formula="";
      
       this.angulo(im);
       
       float suma= (float)(Math.pow(im.real, 2)+ Math.pow(im.imaginaria, 2));
       
       float potencia= (float) 1/(n+2);
        
       float r=(float) Math.pow(suma, potencia);
       /// el arreglo en donde se guardaran los vectores a graficar
       
       
       
       for(int k=0;k<n;k++){
           
           
             float anguloN = (float) ((this.angulo + 2*k*Math.PI )/n);
             
             float auxR, auxI;
             
             auxR=(float) (Math.cos(anguloN)*r);
             auxI=(float) (Math.sin(anguloN)*r);
             
         //se estan guardando los numeros imaginarios en su forma compleja. 
         Imaginarios aux = new Imaginarios(auxR, auxI);   
         
        arreglo.add(aux);
       
         
              formula=formula+"Para k="+k+", "+r+"e^("+anguloN+")i " + " Z= "+auxR+" + i"+auxI+"\n";
              
       }
       
     
       return formula;
   } 
   
      
   
   public String Potencias(Imaginarios im, int n){
       
    float newAngulo;
    
   
    this.angulo(im);
    
    newAngulo= this.getAngulo()*n;
    
    String Formula= "("+this.euler(im)+")^("+n+")= e^("+newAngulo+")i = Cos("+newAngulo+") + iSen("+newAngulo+")";
    
    return Formula;
    
    }
   
   
   
   
   public float ConRadianes(){
       
       return (float) (Math.PI*this.angulo)/180;
       
   }
    
     
     
    
}

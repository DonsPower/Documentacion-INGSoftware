/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NumerosComplejos;


import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;


/**
 *
 * @author César Iván Martínez
 */
public class Vector {
    
    

XYSeries puntos= new XYSeries("Numero complejo");
XYSeries puntos2= new XYSeries("Numero complejo");


public Vector( Imaginarios im){
    
puntos.add(0, 0);
puntos.add(im.real, im.imaginaria);


XYSeriesCollection datos = new XYSeriesCollection();

datos.addSeries(puntos);


JFreeChart linea = ChartFactory.createXYLineChart("NUMEROS IMAGINARIOS", "Parte real", "Parte imaginaria", datos, PlotOrientation.VERTICAL, true, true, true);
//JFreeChart ve = ChartFactory.createBarChart("NUMEROS IMAGINARIOS", "Parte real", "Parte imaginaria", (CategoryDataset) datos, PlotOrientation.VERTICAL, true, true, true);
ChartFrame frame = new ChartFrame("Complejos", linea);
frame.pack();
frame.setVisible(true);


}

public void vectorRaices(){
    
    
    
}



 public static void main(String[] args) {
     
       
       Imaginarios im=new  Imaginarios(1f, 1f);
       Imaginarios im2=new  Imaginarios(7, 7f);
       Conversiones con= new Conversiones();
       
     
       
       Vector vec = new Vector(im);
       
     System.out.println("Este es el modulo; "+im.getModulo());
       
     System.out.println("Este es el modulo; "+im.getModulo());
     
      
     
     
      System.out.println(con.trigonometrica(im));
     
      System.out.println(con.euler(im)); 
      
      
      con.Raices(im, 4);
      
     String a=con.Potencias(im, 4);
      
      System.out.println(a);
    
    
    //System.out.println("Numero: "+im.real+" + i"+im.imaginaria);
    
 }
 
}
